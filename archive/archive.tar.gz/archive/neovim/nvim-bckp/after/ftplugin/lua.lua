-- vim.opt.formatoptions = vim.opt.formatoptions - 'o'
vim.bo.formatprg = "lua-format"
vim.bo.tabstop = 4
vim.bo.shiftwidth = 4
vim.bo.expandtab = true

